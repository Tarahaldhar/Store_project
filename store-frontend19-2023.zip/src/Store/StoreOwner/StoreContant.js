export const getStoreOwner="GET_STORE_OWNER"; 
export const editStore="EDIT_STORE";